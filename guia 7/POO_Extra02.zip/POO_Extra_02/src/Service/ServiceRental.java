
package Service;
import Entity.Film;
import Entity.Rental;
import java.util.Date;
import java.util.Scanner;

public class ServiceRental {
    Scanner read = new Scanner(System.in).useDelimiter("\n");
    
    public Rental createRental(Film f){
        Rental r1 = new Rental();
        Date d1 = new Date();
        
        System.out.println(":::RENTAL:::");
        System.out.println(f.getTitle());
        r1.setFilmRental(f);
        System.out.println(">>>Enter start date of rental");
        System.out.println(">>>dd");
        d1.setDate(read.nextInt());
        System.out.println(">>>mm");
        d1.setMonth(read.nextInt());
        System.out.println(">>>yyyy");
        d1.setYear(read.nextInt());
        r1.setStartDate(d1);
        
        System.out.println(">>>Enter ending date of rental");
        System.out.println(">>>dd");
        d1.setDate(read.nextInt());
        System.out.println(">>>mm");
        d1.setMonth(read.nextInt());
        System.out.println(">>>yyyy");
        d1.setYear(read.nextInt());
        r1.setEndingDate(d1);
        
        System.out.println(":::PRICE OF THE RENTAL FILM:::");
        int rentalDays;
        rentalDays = (r1.getEndingDate().getYear()-r1.getStartDate().getYear())*365;
        rentalDays += (r1.getEndingDate().getMonth()-r1.getStartDate().getMonth())*30;
        rentalDays += (r1.getEndingDate().getDate()-r1.getStartDate().getDate());
        
        if (rentalDays <= 3) {
            r1.setPrice(10);
        }else if(rentalDays > 3){
            r1.setPrice(10+10*0.1*(rentalDays-3));
        }
        System.out.println("--->The price of the rental is: "+r1.getPrice());
        return r1; 
    }
    
    public void showRental(Rental r){
        System.out.println(":::RENTAL DATA:::");
        System.out.println(">>>Film: "+r.getFilmRental());
        System.out.println(">>>Start date: "+r.getStartDate());
        System.out.println(">>>Ending date: "+r.getEndingDate());    
        System.out.println(">>>Price: "+r.getPrice());  
    }
    
    public boolean searchRentalByDate(Rental[] r,Date d){
        for (Rental r1 : r) {
            if (r1.getEndingDate().equals(d)) {
                return true;
            }
        }
        return false;
    }
    
    public Rental showRentalByDate(Rental[] r, Date d){
        for (Rental r1 : r) {
            if (r1.getEndingDate().equals(d)) {
                return r1;
            }
        }
    }
}
