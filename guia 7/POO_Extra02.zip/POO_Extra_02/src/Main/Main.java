
package Main;
import Entity.Film;
import Entity.Rental;
import Service.FilmService;
import Service.ServiceRental;
import java.util.Date;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        FilmService fs1 = new FilmService();
        ServiceRental sr1 = new ServiceRental();
        Rental[] r1 = new Rental[3];
        Film[] f1 = new Film[5];
        
        for (int i = 0; i < 5; i++) {
            f1[i] = fs1.createFilm();
        }
        for (int i = 0; i < 5; i++) {
            fs1.showFilm(f1[i]);
        }
        for (int i = 0; i < 3; i++) {
            r1[i] = sr1.createRental(f1[i]);
        }
        for (int i = 0; i < 3; i++) {
            sr1.showRental(r1[i]);
        }
        
        Date d;
        Scanner read = new Scanner(System.in);
        System.out.println(">>>Enter searching date");
        System.out.println(">>>dd");
        d.setDate(read.nextInt());
        System.out.println(">>>mm");
        d.setMonth(read.nextInt());
        System.out.println(">>>yyyy");
        d.setYear(read.nextInt());
        if (sr1.searchRentalByDate(r1, d)) {
            System.out.println("--->The rental is:");
            sr1.showRental(sr1.showRentalByDate(r1, d));
        }else{
            System.out.println("¡The rental doesn't exist!");
        }
    }   
}
